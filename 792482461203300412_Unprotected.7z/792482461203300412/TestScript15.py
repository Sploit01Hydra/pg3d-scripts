from collections import OrderedDict
from random import choice, randint
from string import hexdigits, ascii_uppercase

from requests import post

HEX = hexdigits[:16]


def _hex_(n):
    return ''.join(choice(HEX) for _ in range(n))


def getauthjson(device_id=_hex_(32), uniq_id='', _hash_='',
                device_model=(choice(["samsung", "huawei", "sony", "pixel", "xiaomi", "oppo", "microsoft", "motorola",
                                      "Google", "grunt", "Lenovo", "Nokia", "HTC", "panasonic", "sharp", "vivo"]),
                              ''.join(choice(ascii_uppercase) for _ in range(2)) + '-' + choice(ascii_uppercase) +
                              ''.join(str(randint(0, 9)) for _ in range(3)) + choice(ascii_uppercase)),
                cpu_model=choice(["ARMv" + str(randint(1, 9)), "armeabi", "AArch" + choice(('32', '64')),
                                  "arm" + choice(('32', '64')), "x86", "x86abi", "Qualcomm " + str(randint(100, 999)),
                                  "Exynos " + str(randint(100, 999))]) + ' ' + choice(
                    ["VFP", "Snapdragon ", ''.join(choice(ascii_uppercase) for _ in range(3))]) + 'v' + str(
                    randint(1, 9)) + ' ' + choice(
                    ("NEON", ''.join(choice(ascii_uppercase) for _ in range(randint(2, 6))))),
                cpu_frequency=str(randint(1000, 9999)), cpu_cores=str(randint(2, 24)), ram=str(randint(1000, 9999)),
                platform='1', version="21.3.1", new_id_v3='0', pg3dhost="pixelgunserver.com"):
    req = post("https://server-v2." + pg3dhost + "/auth/",
               headers=OrderedDict([("Host", "server-v2." + pg3dhost), ("Accept-Encoding", "gzip, identity"),
                                    ("Connection", "Close, TE"), ("TE", "identity"), ("User-Agent", "BestHTTP"),
                                    ("Content-Type", "application/json"), ("Content-Length", ''), ("Accept", None)]),
               data='{"uniq_id":"' + uniq_id + '", "hash":"' + _hash_ + '", "device_id":"' + device_id +
                    '", "device_model":"' + device_model[0] + ' ' + device_model[1] + '", "cpu_model":"' + cpu_model +
                    '", "cpu_frequency":"' + cpu_frequency + '", "cpu_cores":"' + cpu_cores + '", "ram":"' + ram +
                    '", "platform":"' + platform + '", "version":"' + version + '"' +
                    ('' if new_id_v3 == '0' else ', "new_id_v3":"' + new_id_v3 + '"') + '}')
    return req.json(), req.cookies
